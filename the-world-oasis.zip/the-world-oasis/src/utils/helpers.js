import { formatDistance, parseISO, differenceInDays } from "date-fns";

export const subtractDates = (dateStr1, dateStr2) => {
  try {
    return differenceInDays(
      parseISO(String(dateStr1)),
      parseISO(String(dateStr2))
    );
  } catch (error) {
    console.error("Error in subtractDates:", error);
    return null;
  }
};

export const formatDistanceFromNow = (dateStr) => {
  if (typeof dateStr !== "string") {
    console.error("Invalid argument: dateStr must be a string");
    return null;
  }

  try {
    return formatDistance(parseISO(dateStr), new Date(), { addSuffix: true })
      .replace("about ", "")
      .replace("in", "In");
  } catch (error) {
    console.error("Error in formatDistanceFromNow:", error);
    return null;
  }
};

export const getToday = function (options = {}) {
  try {
    const today = new Date();
    if (options?.end) {
      today.setUTCHours(23, 59, 59, 999);
    } else {
      today.setUTCHours(0, 0, 0, 0);
    }
    return today.toISOString();
  } catch (error) {
    console.error("Error in getToday:", error);
    return null;
  }
};

export const formatCurrency = (value) => {
  try {
    return new Intl.NumberFormat("en", {
      style: "currency",
      currency: "USD",
    }).format(value);
  } catch (error) {
    console.error("Error in formatCurrency:", error);
    return null;
  }
};
