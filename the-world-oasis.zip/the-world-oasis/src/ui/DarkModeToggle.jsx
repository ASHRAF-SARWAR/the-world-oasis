import { HiMiniMoon, HiMiniSun } from "react-icons/hi2";
import ButtonIcon from "./ButtonIcon";
import { useDarkMode } from "../hooks/DarkModeContext";

function DarkModeToggle() {
  const { isDarkMode, toggleDarkMode } = useDarkMode();
  return (
    <ButtonIcon onClick={toggleDarkMode}>
      {isDarkMode ? <HiMiniSun /> : <HiMiniMoon />}
    </ButtonIcon>
  );
}

export default DarkModeToggle;
