import { useUser } from "../features/authentication/useUser";

function Avatar() {
  const { user } = useUser();
  const { fullName, avatars } = user;
  return <div>Avatar</div>;
}

export default Avatar;
