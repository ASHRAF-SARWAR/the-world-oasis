import Form from "../../ui/Form";
import FormRow from "../../ui/FormRowVertical";
import Input from "../../ui/Input";
import Spinner from "../../ui/Spinner";
import { useSettings } from "./useSettings";
import { useUpdateSetting } from "./useUpdateSettings";

function UpdateSettingsForm() {
  const {
    isLoading,
    settings: {
      min_BookingLength,
      max_BookingLenght,
      maxGuests,
      hasBreakfast,
    } = {},
  } = useSettings();

  const { isUpdating, updateSetting } = useUpdateSetting();

  function handleUpdateSettings(e, field) {
    const { value } = e.target;
    console.log(value);
    updateSetting({ [field]: value });
  }

  if (isLoading) <Spinner />;
  return (
    <Form>
      <FormRow label="Minimum nights/booking">
        <Input
          type="number"
          id="min-nights"
          defaultValue={min_BookingLength}
          disabled={isUpdating}
          onBlur={(e) => handleUpdateSettings(e, "min_BookingLength")}
        />
      </FormRow>
      <FormRow label="Maximum nights/booking">
        <Input
          type="number"
          id="max-nights"
          defaultValue={max_BookingLenght}
          disabled={isUpdating}
          onBlur={(e) => handleUpdateSettings(e, "max_BookingLenght")}
        />
      </FormRow>
      <FormRow label="Maximum guests/booking">
        <Input
          type="number"
          id="max-guests"
          defaultValue={maxGuests}
          disabled={isUpdating}
          onBlur={(e) => handleUpdateSettings(e, "maxGuests")}
        />
      </FormRow>
      <FormRow label="hasBreakfast price">
        <Input
          type="number"
          id="hasBreakfast-price"
          defaultValue={hasBreakfast}
          disabled={isUpdating}
          onBlur={(e) => handleUpdateSettings(e, "hasBreakfast")}
        />
      </FormRow>
    </Form>
  );
}

export default UpdateSettingsForm;
