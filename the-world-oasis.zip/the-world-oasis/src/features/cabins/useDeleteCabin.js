import { useMutation, useQueryClient } from "@tanstack/react-query";
import { deleteCabins as deleteCabinApi } from "../../services/apiCabins";
import toast from "react-hot-toast";

export function useDeleteCabin() {
  const queryClient = useQueryClient();
  const { isLoading: isDeleting, mutate: deleteCabins } = useMutation({
    mutationFn: deleteCabinApi,
    onSuccess: () => {
      toast.success("Cabin deleted successfully!");
      queryClient.invalidateQueries("cabins");
    },
    onError: (err) => {
      toast.error("Could Not Delete Cabin", err.message);
    },
  });
  return { isDeleting, deleteCabins };
}
