import Filter from "../../ui/Filter";
import SortBy from "../../ui/SortBy";
import TableOperations from "./../../ui/TableOperations";
function CabinsTableOperations() {
  return (
    <TableOperations>
      <Filter
        fieldName="discount"
        options={[
          { value: "all", label: "All" },
          { value: "no-discount", label: "No discount" },
          { value: "discount", label: "Discount" },
        ]}
      />
      <SortBy
        options={[
          { value: "name-asc", label: "Sort By Name (A-Z)" },
          { value: "name-desc", label: "Sort By Name (Z-A)" },
          { value: "regular_price-asc", label: "Sort By Price (A-Z)" },
          { value: "regular_price-desc", label: "Sort By Price (Z-A)" },
          { value: "discount-asc", label: "Sort By Discount (A-Z)" },
          { value: "discount-desc", label: "Sort By Discount (Z-A)" },
        ]}
      ></SortBy>
    </TableOperations>
  );
}

export default CabinsTableOperations;
