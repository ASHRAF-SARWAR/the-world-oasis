import { formatCurrency } from "../../utils/helpers";
import Stat from "./Stat";
import {
  HiOutlineBriefcase,
  HiOutlineBanknotes,
  HiOutlineCalendarDays,
  HiOutlineChartBar,
} from "react-icons/hi2";
function Stats({ bookings, confirmedStays, numDays, countCabins }) {
  const bookingLenght = bookings?.length;

  const sales = bookings?.reduce((acc, arr) => acc + arr.totalPrice, 0);
  const checkins = confirmedStays?.length;
  console.log(countCabins);

  const occupencyrate =
    confirmedStays?.reduce((acc, arr) => acc + arr.numNights, 0) /
    (numDays * countCabins);

  console.log(occupencyrate);
  //   const checkins = confirmedStays.length;
  return (
    <>
      <Stat
        title="bookings"
        color="blue"
        icon={<HiOutlineBriefcase />}
        value={bookingLenght}
      />
      <Stat
        title="sales"
        value={formatCurrency(sales)}
        color="green"
        icon={<HiOutlineBanknotes />}
      />
      <Stat
        title="checkins"
        value={checkins}
        color="indigo"
        icon={<HiOutlineCalendarDays />}
      />
      <Stat
        title="occupency rate"
        value={Math.round(occupencyrate * 100) + "%"}
        color="yellow"
        icon={<HiOutlineChartBar />}
      />
    </>
  );
}

export default Stats;
