import styled from "styled-components";
import BookingDataBox from "../../features/bookings/BookingDataBox";

import Row from "../../ui/Row";
import Heading from "../../ui/Heading";
import ButtonGroup from "../../ui/ButtonGroup";
import Button from "../../ui/Button";
import ButtonText from "../../ui/ButtonText";

import { useMoveBack } from "../../hooks/useMoveBack";
import { useBooking } from "../bookings/useBooking";
import Checkbox from "./../../ui/Checkbox";
import { useEffect, useState } from "react";
import Spinner from "../../ui/Spinner";
import { useCheckin } from "./useCheckin";
import { useSettings } from "../settings/useSettings";
import { formatCurrency } from "../../utils/helpers";
import Tag from "../../ui/Tag";

const Box = styled.div`
  /* Box */
  background-color: var(--color-grey-0);
  border: 1px solid var(--color-grey-100);
  border-radius: var(--border-radius-md);
  padding: 2.4rem 4rem;
`;
const HeadingGroup = styled.div`
  display: flex;
  gap: 2.4rem;
  align-items: center;
`;

function CheckinBooking() {
  const moveBack = useMoveBack();
  const [isConfirmed, setIsConfirmed] = useState(true);
  const [addBreakFast, setAddBreakFast] = useState(false);

  const { booking, isLoading } = useBooking();
  const { checkin, isChecking } = useCheckin();
  const { settings, isLoading: isSetting } = useSettings() || {};

  const {
    id: bookingId,
    status,
    guests,
    totalPrice,
    numGuests,
    breakFast: hasBreakfast,
    numNights,
  } = booking || {};
  console.log(settings);

  // const hasbreakfast = settings?.breakFast || 1;
  const optionBreakFastPrice = settings?.breakFast * numGuests * numNights;
  useEffect(() => {
    setIsConfirmed(booking?.isPaid ?? false);
  }, [booking?.isPaid]);

  function handleCheckin() {
    if (!isConfirmed) return;

    if (addBreakFast) {
      checkin({
        bookingId,
        breakfast: {
          hasBreakfast: true,
          extraPrice: optionBreakFastPrice,
          totalPrice: totalPrice + optionBreakFastPrice,
        },
      });
    } else {
      checkin(bookingId);
    }
  }

  if (isLoading || isChecking || isSetting) return <Spinner />;
  const statusToTagName = {
    unconfirmed: "blue",
    "checked-in": "green",
    "checked-out": "silver",
  };
  return (
    <>
      <Row type="horizontal">
        <HeadingGroup>
          <Heading as="h1">Check in booking #{bookingId}</Heading>
          <Tag type={statusToTagName[status]}>{status}</Tag>
        </HeadingGroup>

        <ButtonText onClick={moveBack}>&larr; Back</ButtonText>
      </Row>

      <BookingDataBox booking={booking} />

      {!hasBreakfast && (
        <Box>
          <Checkbox
            checked={addBreakFast}
            onChange={() => {
              setIsConfirmed(false);
              setAddBreakFast((confirm) => !confirm);
            }}
            id="breakfast"
          >
            want to Add breakfast for {optionBreakFastPrice}
          </Checkbox>
        </Box>
      )}

      <Box>
        <Checkbox
          checked={isConfirmed}
          disabled={isConfirmed || isChecking}
          onChange={() => setIsConfirmed((confirm) => !confirm)}
          id="confirm"
        >
          I confirmed that {guests.fullName} has paid{" "}
          {!addBreakFast
            ? `${totalPrice}`
            : `${formatCurrency(
                totalPrice + optionBreakFastPrice
              )}(${totalPrice} + ${optionBreakFastPrice})`}
        </Checkbox>
      </Box>
      <ButtonGroup>
        {checkin.status !== "checked-in" && (
          <Button onClick={handleCheckin} disabled={!isConfirmed}>
            Check in booking #{bookingId}
          </Button>
        )}

        <Button variation="secondary" onClick={moveBack}>
          Back
        </Button>
      </ButtonGroup>
    </>
  );
}

export default CheckinBooking;
