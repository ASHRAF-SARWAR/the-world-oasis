import { useMutation } from "@tanstack/react-query";
import { signup as signupApi } from "../../services/apiAuth";
import toast from "react-hot-toast";

export function useSignup() {
  const { mutate: signup, isLoading } = useMutation({
    mutationFn: signupApi,
    onSuccess: (user) => {
      toast.success(
        "Account created SuccessFully! Please verify the email by existing users"
      );
    },
    // onError: (error) => {
    //   toast.error("Could not create account" + error.message);
    // },
  });
  return { signup, isLoading };
}
