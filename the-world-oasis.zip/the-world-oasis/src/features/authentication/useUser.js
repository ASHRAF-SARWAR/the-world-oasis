import { useQuery, useQueryClient } from "@tanstack/react-query";
import { GetCurrentUser } from "../../services/apiAuth";
import toast from "react-hot-toast";

export function useUser() {
  const queryClient = useQueryClient();
  const { data: user, isLoading } = useQuery({
    queryFn: GetCurrentUser,
    queryKey: ["user"],
    onSuccess: (user) => {
      queryClient.setQueryData(["user"], user?.user);
      console.log(user);
    },
    onError: (error) => {
      toast.error("Could not get user");
    },
  });

  return { user, isLoading, isAuthenticated: user?.role === "authenticated" };
}
