import { useForm } from "react-hook-form";
import Button from "../../ui/Button";
import Form from "../../ui/Form";

import Input from "../../ui/Input";

import FormRowVertical from "../../ui/FormRowVertical";
import { useEditingAccount } from "../../services/useEditAccount";

function UpdatePasswordForm() {
  const { register, handleSubmit, formState, getValues, reset } = useForm();
  const { errors } = formState;

  const { updateUser, isUpdating } = useEditingAccount();

  function onSubmit({ password }) {
    updateUser({ password }, { onSuccess: reset });
  }

  return (
    <Form onSubmit={handleSubmit(onSubmit)}>
      <FormRowVertical
        label="Password (min 8 characters)"
        error={errors?.password?.message}
      >
        <Input
          type="password"
          id="password"
          autoComplete="current-password"
          disabled={isUpdating}
          {...register("password", {
            required: "This field is required",
            minLength: {
              value: 8,
              message: "Password needs a minimum of 8 characters",
            },
          })}
        />
      </FormRowVertical>

      <FormRowVertical
        label="Confirm password"
        error={errors?.passwordConfirm?.message}
      >
        <Input
          type="password"
          autoComplete="new-password"
          id="passwordConfirm"
          disabled={isUpdating}
          {...register("passwordConfirm", {
            required: "This field is required",
            validate: (value) =>
              getValues().password === value || "Passwords need to match",
          })}
        />
      </FormRowVertical>
      <FormRowVertical>
        <Button type="reset" variation="secondary" onClick={reset}>
          Cancel
        </Button>
        <Button disabled={isUpdating}>Update password</Button>
      </FormRowVertical>
    </Form>
  );
}

export default UpdatePasswordForm;
