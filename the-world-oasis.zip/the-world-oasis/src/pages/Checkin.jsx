import CheckinBooking from "../features/check-in-out/CheckinBooking";

function Checkin() {
  return (
    <div>
      <CheckinBooking />
    </div>
  );
}

export default Checkin;
