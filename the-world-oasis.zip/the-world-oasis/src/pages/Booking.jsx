import BookingDetail from "./../features/bookings/BookingDetail";
function Booking() {
  return (
    <div>
      <BookingDetail />
    </div>
  );
}

export default Booking;
