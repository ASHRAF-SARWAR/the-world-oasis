import { useMutation, useQueryClient } from "@tanstack/react-query";
import toast from "react-hot-toast";
import { updateUserData } from "../services/apiAuth";

export function useEditingAccount() {
  const queryClient = useQueryClient();
  const { mutate: updateUser, isLoading: isEditingAccount } = useMutation({
    mutationFn: updateUserData,
    onSuccess: (user) => {
      toast.success("User account updated succesfully");
      queryClient.setQueriesData(["user"], user);
      queryClient.invalidateQueries({ queryKey: ["user"] });
    },
    onError: (err) => toast.error(err.message),
  });
  return { isEditingAccount, updateUser };
}
