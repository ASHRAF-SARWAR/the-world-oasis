import { createClient } from "@supabase/supabase-js";

// Your Supabase URL and Key
const supabaseUrl = "https://qkbxvgyfgvwxplzyaafo.supabase.co";
const supabaseKey =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFrYnh2Z3lmZ3Z3eHBsenlhYWZvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MDc3NDA4MzQsImV4cCI6MjAyMzMxNjgzNH0.PqGp825j6Mh1f-fIbrxJ9gFsk44uA1QJtCWPJLEt4C4";

// Create a Supabase client
const supabase = createClient(supabaseUrl, supabaseKey);

export { supabase, supabaseUrl };
