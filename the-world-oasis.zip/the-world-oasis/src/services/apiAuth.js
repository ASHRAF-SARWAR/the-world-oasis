import { supabase, supabaseUrl } from "./supabase";

export async function login({ email, password }) {
  let { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });

  if (error) {
    throw new Error("Could not be log in");
  }

  console.log(data);
  return data;
}

export async function GetCurrentUser() {
  const { data: session } = await supabase.auth.getSession();

  if (!session.session) return null;

  const { data, error } = await supabase.auth.getUser();

  if (error) {
    throw new Error("Could not get user");
  }

  return data?.user;
}

export async function logout() {
  const { error } = await supabase.auth.signOut();
  if (error) throw new Error("Could not log out");
}

export async function signup({ fullName, email, password }) {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: {
        fullName,
        avatars: "",
      },
    },
  });
  if (error) throw new Error("Could not Sign up");

  return data;
}

export async function updateUserData({ fullName, password, avatar }) {
  let updateData;
  if (password) updateData = { password };
  if (fullName) updateData = { data: { fullName } };
  // updata Name or Password
  const { data, error } = await supabase.auth.updateUser(updateData);

  if (error) throw new Error("Name or password Could not be updated");
  console.log(data);

  if (!avatar) return data;

  console.log(data);
  //https://qkbxvgyfgvwxplzyaafo.supabase.co/storage/v1/object/public/avatars/avatar-ae437acc-a7da-4720-8006-504019144c84

  // upload avatars
  const fileName = `avatar-${data?.user?.id}?${Math.random()}`;

  const { error: storageError } = supabase.storage
    .from("avatars")
    .upload(fileName, avatar);
  if (storageError) throw new Error("Avatar Could not be uploaded");

  // update user data
  const { data: updatedUser, error: error2 } = supabase.auth.updateUser({
    data: {
      avatars: `${supabaseUrl}/storage/v1/object/public/avatars/${fileName}`,
    },
  });
  if (error2) throw new Error("Avatar Could not be updated");

  return updatedUser;
}
