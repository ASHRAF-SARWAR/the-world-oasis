import { supabase, supabaseUrl } from "./supabase";

export async function getCabins() {
  const { data, error } = await supabase.from("cabins").select("*");

  if (error) {
    console.error(error);
    throw new Error("Cabins could not be fetched");
  }
  return data;
}

export async function deleteCabins(id) {
  const { data, error } = await supabase.from("cabins").delete().eq("id", id);
  if (error) {
    console.error(error);
    throw new Error("Cabin could not be deleted");
  }
  return data;
}

export async function insertEditCabins(newCabin, id) {
  try {
    const hasImage = newCabin.image?.startsWith?.(supabaseUrl);

    const imageName = `${newCabin.image.name}?${Math.random()}`.replaceAll(
      "/",
      ""
    );

    const imagePath = hasImage
      ? newCabin.image
      : `${supabaseUrl}/storage/v1/object/public/cabins-image/${imageName}`;

    let query = supabase.from("cabins");

    if (!id) query = query.insert([{ ...newCabin, image: imagePath }]);

    if (id)
      query = query.update([{ ...newCabin, image: imagePath }]).eq("id", id);

    const { data, error } = await query.select().single();

    if (error) {
      console.error(error);
      throw new Error("Cabin could not be created/edited");
    }

    console.log(data);

    if (hasImage) return data;

    // if (!hasImage) {
    // const { error: storageError } = await supabase.storage
    //   .from("cabins-image")
    //   .upload(imageName, newCabin.image);

    // if (storageError) {
    //   console.error(storageError);
    //   await supabase.from("cabins").delete().eq("id", data.id);
    //   throw new Error(
    //     "Image could not be uploaded, so Cabin could not be created/edited"
    //   );
    //   //   }
    // }

    return data;
  } catch (error) {
    console.error(error);
    throw new Error(
      "An error occurred while creating/editing cabin. Please try again."
    );
  }
}
