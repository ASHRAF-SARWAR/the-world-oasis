import { supabase, supabaseUrl } from "./supabase";

export async function getCabins() {
  const { data, error } = await supabase.from("cabins").select("*");

  if (error) {
    console.error(error);
    throw new error("Cabins could not be fetched");
  }
  return data;
}

export async function deletCabins(id) {
  const { data, error } = await supabase.from("cabins").delete().eq("id", id);
  if (error) {
    console.error(error);
    throw new error("Cabins could not be fetched");
  }
  return data;
}

export async function insertEditCabins(newCabin) {
  const imageName = `${newCabin.image.name}?${Math.random()}`.replaceAll(
    "/",
    ""
  );
  // https://qkbxvgyfgvwxplzyaafo.supabase.co/storage/v1/object/public/cabins-image/cabin-002.jpg?t=2024-02-12T13%3A23%3A39.313Z

  const imagePath = `${supabaseUrl}/storage/v1/object/public/cabins-image/${imageName}`;

  const { data, error } = await supabase
    .from("cabins")
    .insert([{ ...newCabin, image: imagePath }]);

  if (error) {
    console.error(error);
    throw new error("Cabins could not be created");
  }
  console.log(data);

  const { error: storageError } = await supabase.storage
    .from("cabins-image")
    .upload(imageName, newCabin.image);

  if (storageError) {
    console.error(storageError);
    await supabase.from("cabins").delete().eq("id", data.id);
    throw new error(
      "Image can't be uploaded and so Cabin could not be created"
    );
  }
  return data;
}
